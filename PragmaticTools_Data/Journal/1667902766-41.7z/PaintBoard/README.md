# paintBoard

## Summary
- This is a project to simulate a app like Windows Paint.

## How To use
- Way 1:  

    > python paintBoard.pyw
- Way 2:  

    > double click paintBoard.pyw
##  Warning
- The package that paintBoard use:  
    ``` python
        import PIL #pip install pillow
        import matplotlib #pip install matplotlib
        import webcolors # pip install webcolors
        import ttkbootstrap #pip install ttkbootstrap
        import webbrowser 
    ```
-  Before use the paintBoard, you must install :

    - ghostScript: https://www.ghostscript.com/releases/gsdnld.html
    - the packages

## Update history
- 2022/7/10  verson 1.0.0  
    > Basic Functions  
- 2022/7/17  verson 1.0.7  
    > New charting features
    
